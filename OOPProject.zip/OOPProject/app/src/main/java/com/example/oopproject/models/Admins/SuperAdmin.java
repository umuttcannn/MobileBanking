package com.example.oopproject.models.Admins;

import com.example.oopproject.models.Users.User;

public class SuperAdmin extends Admin implements IAdmin {
    public SuperAdmin(String ad, String pw) {
        super(ad, pw);
    }

    @Override
    public void kullaniciSil(User user) {
        super.kullaniciSil(user);
    }

    @Override
    public void kullaniciGuncelle(int bakiye, String tc, String ad, String soyad, String hesapNo, String pw, int id, String type) {
        super.kullaniciGuncelle(bakiye, tc, ad, soyad, hesapNo, pw, id, type);
    }

    public void adminGuncelle(int adminId)
    {
        // TODO
    }

    public void adminSil(Admin admin)
    {
        // TODO
    }
}
