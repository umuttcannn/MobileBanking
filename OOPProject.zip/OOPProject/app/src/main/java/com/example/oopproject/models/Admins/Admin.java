package com.example.oopproject.models.Admins;

import android.content.Context;

import com.example.oopproject.MyDatabaseHelper;
import com.example.oopproject.models.Users.User;

public class Admin {
    private String ad,pw;
    private int id;
    private Context context;

    private MyDatabaseHelper myDB;

    public Admin(String ad, String pw) {
        this.ad = ad;
        this.pw = pw;
    }

    public Admin(String ad, String pw, Context context) {
        this.ad = ad;
        this.pw = pw;
        this.context = context;
        myDB = new MyDatabaseHelper(context);
    }

    public Admin(Context context)
    {
        this.context = context;
        myDB = new MyDatabaseHelper(context);
    }


    public void kullaniciGuncelle(int bakiye,String tc,String ad,String soyad,String hesapNo,String pw,int id,String type)
    {
        if (myDB==null)
        {
            myDB = new MyDatabaseHelper(context);

        }
        myDB.kullaniciGuncelle(bakiye, tc, ad, soyad, hesapNo, pw, id, type);
    }

    public void kullaniciSil(User user)
    {
        if (myDB==null)
        {
            myDB = new MyDatabaseHelper(context);

        }

        myDB.deleteUser(user.getTc());
    }

    public String getAd() {
        return ad;
    }



    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
