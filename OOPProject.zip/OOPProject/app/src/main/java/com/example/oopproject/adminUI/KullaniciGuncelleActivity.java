package com.example.oopproject.adminUI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.oopproject.R;
import com.example.oopproject.models.Admins.Admin;

import java.util.Locale;

public class KullaniciGuncelleActivity extends AppCompatActivity {

    private EditText etUpdateid,etUpdatePw,etUpdateTc,etUpdateAd,etUpdateSoyad,etUpdateHesapNo,etUpdateVergiNo,etUpdateType,etUpdateBakiye;
    private Button btnGuncelle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kullanici_guncelle);

        Intent intent = getIntent();

        int id = intent.getIntExtra("id",0);
        String hesapNo = intent.getStringExtra("hesapNo");
        String type = intent.getStringExtra("type");

        tanimla();

        btnGuncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pw = etUpdatePw.getText().toString();
                String tc = etUpdateTc.getText().toString();
                String ad = etUpdateAd.getText().toString();
                String soyad = etUpdateSoyad.getText().toString();
                int bakiye = Integer.parseInt(etUpdateBakiye.getText().toString());

                Admin admin = new Admin(KullaniciGuncelleActivity.this);

                admin.kullaniciGuncelle(bakiye,tc,ad,soyad,hesapNo,pw,id,type);



            }
        });



    }

    private void tanimla() {
        etUpdateAd = findViewById(R.id.etUpdateAd);
        etUpdatePw = findViewById(R.id.etUpdatePw);
        etUpdateTc = findViewById(R.id.etUpdateTc);
        btnGuncelle = findViewById(R.id.btnGuncelle);
        etUpdateSoyad = findViewById(R.id.etUpdateSoyad);
        etUpdateBakiye = findViewById(R.id.etUpdateBakiye);

    }
}