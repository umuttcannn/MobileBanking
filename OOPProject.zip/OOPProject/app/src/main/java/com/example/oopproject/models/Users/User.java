package com.example.oopproject.models.Users;

import android.content.Context;

import com.example.oopproject.MyDatabaseHelper;
import com.example.oopproject.models.Credits.Kredi;
import com.example.oopproject.models.ParametricVariables;

import java.util.ArrayList;

public class User {
    private int id,bakiye;
    private String ad,soyad,tc,pw,hesapNo;
    Context context;
    MyDatabaseHelper myDB;

    public User(int bakiye, String ad, String soyad, String tc, String pw, String hesapNo) {
        this.bakiye = bakiye;
        this.ad = ad;
        this.soyad = soyad;
        this.tc = tc;
        this.pw = pw;
        this.hesapNo = hesapNo;
    }

    public User(int id, int bakiye, String ad, String soyad, String tc, String pw, String hesapNo, Context context) {
        this.bakiye = bakiye;
        this.ad = ad;
        this.soyad = soyad;
        this.tc = tc;
        this.pw = pw;
        this.id = id;
        this.hesapNo = hesapNo;
        this.context = context;
        myDB = new MyDatabaseHelper(context);
    }

    public User(Context context){
        this.context = context;
        myDB = new MyDatabaseHelper(context);
    }

    public void bakiyeGuncelle(int miktar)
    {
        if (myDB==null)
        {
            myDB = new MyDatabaseHelper(context);
        }

        myDB.bakiyeGüncelle(myDB.getBakiye(tc)+miktar,
                tc,
                myDB.getUserName(tc),
                myDB.getUserSurname(tc),
                myDB.getUserHesapNo(tc),
                pw,
                myDB.getId(tc));
    }

    public int krediCek(Kredi kredi)
    {
        if (myDB==null)
        {
            myDB = new MyDatabaseHelper(context);
        }

        myDB.addKredi(hesapNo,kredi.getMiktar(),kredi.getTaksitSayisi(),kredi.getKalanMiktar());
        return kredi.getMiktar();
    }

    public double krediFaizHesaplama(int cekilenMiktar, int taksitSayisi)
    {
        return 0;
    }

    // Overload
    public void krediKapat(Kredi kredi)
    {
        if (myDB==null)
        {
            myDB = new MyDatabaseHelper(context);
        }

        myDB.krediKapat(kredi.getId());
    }
    // Overload
    public void krediKapat(ArrayList<Kredi> krediArrayList)
    {
        for (Kredi kredi : krediArrayList)
        {
            for (int i = 0;i<kredi.getTaksitSayisi();i++)
            {
                krediTaksitOde(kredi);
            }
            myDB.krediKapat(kredi.getId());
        }

    }

    public void krediTaksitOde(Kredi kredi)
    {
        if (myDB==null)
        {
            myDB = new MyDatabaseHelper(context);
        }

        myDB.krediOde(kredi.getId(),
                kredi.getMiktar(),
                kredi.getAylikTaksit(),
                kredi.getKalanMiktar(),
                kredi.getTaksitSayisi(),
                kredi.getOwnerNo()
        );

        bakiyeGuncelle(((int)(-kredi.getAylikTaksit())) );
    }

    public void displayDB()
    {
        myDB.displayDB();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBakiye() {
        return bakiye;
    }

    public void setBakiye(int miktar) {
        this.bakiye = miktar;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getTc() {
        return tc;
    }

    public void setTc(String tc) {
        this.tc = tc;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public String getHesapNo() {
        return hesapNo;
    }

    public void setHesapNo(String hesapNo) {
        this.hesapNo = hesapNo;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public MyDatabaseHelper getMyDB() {
        return myDB;
    }

    public void setMyDB(MyDatabaseHelper myDB) {
        this.myDB = myDB;
    }

}
