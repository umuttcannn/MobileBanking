package com.example.oopproject.krediUI;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.oopproject.MainActivity;
import com.example.oopproject.MyDatabaseHelper;
import com.example.oopproject.R;
import com.example.oopproject.UserBottomNavigationActivity;
import com.example.oopproject.bakiyeUI.TransferActivity;
import com.example.oopproject.models.Credits.Kredi;
import com.example.oopproject.models.ParametricVariables;
import com.example.oopproject.models.Users.BusinessUser;
import com.example.oopproject.models.Users.FarmerUser;
import com.example.oopproject.models.Users.InternalEmployeeUser;
import com.example.oopproject.models.Users.RetiredUser;
import com.example.oopproject.models.Users.SmeUser;
import com.example.oopproject.models.Users.User;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class KredicekActivity extends AppCompatActivity {

    private Button krediOnay;
    private EditText krediMiktari,taksitSayisi;
    private Spinner krediTaksitSpinner;
    private TextView odemePlaniTV,krediFaizTV,faizMiktariKrediCek,tvGeriOdememiktari;
    private int ItaksitSayisi;
    private String[] taksitSayisiArray = {"3","6","9","12","24","36"};
    private ArrayAdapter<String> adapterForSpinner;
    private double faizOrani;
    private double geriOdemeTutari;

    MyDatabaseHelper myDB;

    private Kredi gKredi = new Kredi(this);

    private ArrayList<User> userArrayList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kredicek);
        tanimla();


        Bundle gameData = getIntent().getExtras();
        String tc = gameData.getString("tc");
        String pw = gameData.getString("pw");

        SharedPreferences prefs = getSharedPreferences("MY_PREFS_NAME", MODE_PRIVATE);
        String hesapNo = prefs.getString("hesapNo", "No name defined");



        adapterForSpinner = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,taksitSayisiArray);
        adapterForSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        myDB = new MyDatabaseHelper(KredicekActivity.this);


        krediFaizTV.setText("KREDİ ÇEKME EKRANINA HOŞGELDİNİZ HESAP TÜRÜNÜZ "  +  myDB.getType(hesapNo).toUpperCase());

        faizMiktariKrediCek.setText("HESAP TÜRÜNÜZ " + myDB.getType(hesapNo).toUpperCase() + " OLDUĞUNDAN DOLAYI SİZE SUNDUĞUMUZ FAİZ ORANI ");

        if (myDB.getType(hesapNo).equals("FARMER"))
        {
            FarmerUser userGlobal = new FarmerUser(myDB.getId(hesapNo),
                    myDB.getBakiye(tc),
                    myDB.getUserName(tc),
                    myDB.getUserSurname(tc),
                    tc,
                    pw,
                    myDB.getUserHesapNo(tc),
                    KredicekActivity.this);

            userArrayList.add(userGlobal);

            faizMiktariKrediCek.append(String.valueOf(ParametricVariables.FARMER_KREDIFAIZORANI));
        }
        else if (myDB.getType(hesapNo).equals("SME"))
        {

            SmeUser userGlobal = new SmeUser(myDB.getId(hesapNo),
                    myDB.getBakiye(tc),
                    myDB.getUserName(tc),
                    myDB.getUserSurname(tc),
                    tc,
                    pw,
                    myDB.getUserHesapNo(tc),
                    KredicekActivity.this);

            userArrayList.add(userGlobal);
            faizMiktariKrediCek.append(String.valueOf(ParametricVariables.SME_KREDIFAIZORANI));
        }
        else if(myDB.getType(hesapNo).equals("INTERNAL"))
        {

            InternalEmployeeUser userGlobal = new InternalEmployeeUser(myDB.getId(hesapNo),
                    myDB.getBakiye(tc),
                    myDB.getUserName(tc),
                    myDB.getUserSurname(tc),
                    tc,
                    pw,
                    myDB.getUserHesapNo(tc),
                    KredicekActivity.this);
            userArrayList.add(userGlobal);

            faizMiktariKrediCek.append(String.valueOf(ParametricVariables.INTERNAL_KREDIFAIZORANI));
        }
        else if (myDB.getType(hesapNo).equals("BUSINESS"))
        {
            BusinessUser userGlobal = new BusinessUser(myDB.getIDfromNo(hesapNo),
                    myDB.getBakiyefromNo(hesapNo),
                    myDB.getUserNamefromHesapNo(hesapNo),
                    myDB.getUserSurnamefromHesapNo(hesapNo),
                    myDB.getTcFromNo(hesapNo),
                    myDB.getPwFromNo(hesapNo),
                    hesapNo,
                    KredicekActivity.this);
            userArrayList.add(userGlobal);
            faizMiktariKrediCek.append(String.valueOf(ParametricVariables.BUSINESS_KREDIFAIZORANI));
        }
        else if (myDB.getType(hesapNo).equals("RETIRED"))
        {

            RetiredUser userGlobal = new RetiredUser(myDB.getId(hesapNo),
                    myDB.getBakiye(tc),
                    myDB.getUserName(tc),
                    myDB.getUserSurname(tc),
                    tc,
                    pw,
                    myDB.getUserHesapNo(tc),
                    KredicekActivity.this);
            userArrayList.add(userGlobal);


            faizMiktariKrediCek.append(String.valueOf(ParametricVariables.RETIRED_KREDIFAIZORANI));
        }


        krediTaksitSpinner.setAdapter(adapterForSpinner);

        krediTaksitSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                ItaksitSayisi = Integer.parseInt(adapterView.getSelectedItem().toString());
                if (!krediMiktari.getText().toString().equals(""))
                {
                    DecimalFormat formatter = new DecimalFormat("#0.00");
                    int cekilenMiktar = Integer.parseInt(krediMiktari.getText().toString());

                    double aylikOdeme = userArrayList.get(0).krediFaizHesaplama(cekilenMiktar,ItaksitSayisi);

                    //double aylikOdeme = gKredi.aylikTaksitHesaplama(cekilenMiktar,ItaksitSayisi,myDB.getType(hesapNo));

                    odemePlaniTV.setText("KREDİNİZİN AYLIK ODEME MIKTARI = " + formatter.format(aylikOdeme) + " TL");

                    geriOdemeTutari = gKredi.geriOdemeHesaplama(aylikOdeme,ItaksitSayisi);

                    tvGeriOdememiktari.setText("TOPLAM GERİ ODENECEK MIKTAR : " + formatter.format(geriOdemeTutari) + " TL");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        krediOnay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int miktar = Integer.parseInt(krediMiktari.getText().toString());

                if (myDB.getType(hesapNo).equals("BUSINESS"))
                {

                    Kredi kredi = new Kredi(hesapNo,miktar,ItaksitSayisi,geriOdemeTutari);

                    User user = new User(myDB.getIDfromNo(hesapNo),
                                    myDB.getBakiyefromNo(hesapNo),
                                    myDB.getUserNamefromHesapNo(hesapNo),
                                    myDB.getUserSurnamefromHesapNo(hesapNo),
                                    myDB.getTcFromNo(hesapNo),
                                    myDB.getPwFromNo(hesapNo),
                                    hesapNo,
                                    KredicekActivity.this);

                    user.bakiyeGuncelle(user.krediCek(kredi));

                }
                else
                {
                    //myDB.addKredi(myDB.getUserHesapNo(hesapNo),miktar,ItaksitSayisi,geriOdemeTutari);

                    Kredi kredi = new Kredi(hesapNo,miktar,ItaksitSayisi,geriOdemeTutari);

                    User user = new User(myDB.getId(hesapNo),
                            myDB.getBakiye(tc),
                            myDB.getUserName(tc),
                            myDB.getUserSurname(tc),
                            tc,
                            pw,
                            myDB.getUserHesapNo(tc),
                            KredicekActivity.this);

                    user.bakiyeGuncelle(user.krediCek(kredi));

                }

                // get all credit
                ArrayList<Kredi> krediArrayList = new ArrayList<>();
                krediArrayList = gKredi.getAllCredit();

                // print all credit
                gKredi.printAllCredit(krediArrayList);


                Intent intent = new Intent(KredicekActivity.this, UserBottomNavigationActivity.class);
                intent.putExtra("tc",tc);
                intent.putExtra("pw",pw);
                startActivity(intent);
            }
        });

    }
    private void tanimla() {
        krediOnay = findViewById(R.id.krediCekonayButton);
        krediMiktari = findViewById(R.id.krediCekMiktar);
        krediTaksitSpinner = findViewById(R.id.spinnerKrediTaksit);
        odemePlaniTV = findViewById(R.id.odemePlaniTV);
        krediFaizTV = findViewById(R.id.krediFaizTV);
        tvGeriOdememiktari = findViewById(R.id.tvGeriOdememiktari);
        faizMiktariKrediCek = findViewById(R.id.faizMiktariKrediCek);
    }
}