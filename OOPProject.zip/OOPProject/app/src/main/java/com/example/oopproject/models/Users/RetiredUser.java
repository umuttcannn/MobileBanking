package com.example.oopproject.models.Users;

import android.content.Context;

import com.example.oopproject.models.Credits.Kredi;
import com.example.oopproject.models.ParametricVariables;

import java.util.ArrayList;

public class RetiredUser extends SeperateUser{
    public RetiredUser(int bakiye, String ad, String soyad, String tc, String pw, String hesapNo) {
        super(bakiye, ad, soyad, tc, pw, hesapNo);
    }

    public RetiredUser(int bakiye, String ad, String soyad, String tc, String pw, String hesapNo, Context context) {
        super(bakiye, ad, soyad, tc, pw, hesapNo, context);
    }

    public RetiredUser(int id, int bakiye, String ad, String soyad, String tc, String pw, String hesapNo, Context context) {
        super(id, bakiye, ad, soyad, tc, pw, hesapNo, context);
    }

    public RetiredUser(Context context) {
        super(context);
    }

    @Override
    public double krediFaizHesaplama(int cekilenMiktar, int taksitSayisi) {
        return (cekilenMiktar/taksitSayisi)+((cekilenMiktar/taksitSayisi)*(ParametricVariables.RETIRED_KREDIFAIZORANI /10));
    }

    @Override
    public void bakiyeGuncelle(int miktar) {
        super.bakiyeGuncelle(miktar);
    }

    @Override
    public int krediCek(Kredi kredi) {
        return super.krediCek(kredi);
    }

}
