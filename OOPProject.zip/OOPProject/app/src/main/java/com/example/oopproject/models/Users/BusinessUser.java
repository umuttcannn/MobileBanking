package com.example.oopproject.models.Users;

import android.content.Context;

import com.example.oopproject.models.Credits.Kredi;
import com.example.oopproject.models.ParametricVariables;

import java.util.ArrayList;

public class BusinessUser extends User{
    public BusinessUser(int bakiye, String ad, String soyad, String tc, String pw, String hesapNo) {
        super(bakiye, ad, soyad, tc, pw, hesapNo);
    }

    public BusinessUser(int id, int bakiye, String ad, String soyad, String tc, String pw, String hesapNo, Context context) {
        super(id, bakiye, ad, soyad, tc, pw, hesapNo, context);
    }

    public BusinessUser(Context context) {
        super(context);
    }


    @Override
    public double krediFaizHesaplama(int cekilenMiktar, int taksitSayisi) {
        return (cekilenMiktar/taksitSayisi)+((cekilenMiktar/taksitSayisi)*(ParametricVariables.BUSINESS_KREDIFAIZORANI /10));
    }

    @Override
    public void krediKapat(Kredi kredi) {
        super.krediKapat(kredi);
    }

    @Override
    public void krediKapat(ArrayList<Kredi> krediArrayList) {
        super.krediKapat(krediArrayList);
    }

    @Override
    public void krediTaksitOde(Kredi kredi) {
        super.krediTaksitOde(kredi);
    }

    @Override
    public void displayDB() {
        super.displayDB();
    }
}
