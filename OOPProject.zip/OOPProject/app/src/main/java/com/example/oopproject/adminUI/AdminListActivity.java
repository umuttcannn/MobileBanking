package com.example.oopproject.adminUI;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.oopproject.R;

public class AdminListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_list);
    }
}