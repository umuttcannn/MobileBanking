package com.example.oopproject.models.Credits;

import android.content.Context;
import android.util.Log;

import com.example.oopproject.MyDatabaseHelper;
import com.example.oopproject.models.ParametricVariables;

import java.util.ArrayList;

public class Kredi {

    private int id,miktar,taksitSayisi;
    private String ownerNo;
    private double aylikTaksit,kalanMiktar;
    private Context context;

    MyDatabaseHelper myDB;


    public Kredi(int id, int miktar, int taksitSayisi, String ownerNo, double aylikTaksit, double kalanMiktar) {
        this.id = id;
        this.miktar = miktar;
        this.taksitSayisi = taksitSayisi;
        this.ownerNo = ownerNo;
        this.aylikTaksit = aylikTaksit;
        this.kalanMiktar = kalanMiktar;
    }

    public Kredi(Context context) {
        this.context = context;
        myDB = new MyDatabaseHelper(context);
    }

    public Kredi(String hesapNo, int miktar, int itaksitSayisi, double geriOdemeTutari) {
        this.taksitSayisi = itaksitSayisi;
        this.ownerNo = hesapNo;
        this.aylikTaksit = geriOdemeTutari/itaksitSayisi;
        this.kalanMiktar = geriOdemeTutari;
        this.miktar = miktar;
    }


    public ArrayList<Kredi> getAllCredit()
    {
        return myDB.getKrediList();
    }

    public double geriOdemeHesaplama(double aylikOdeme, int taksitSayisi)
    {
        return aylikOdeme*taksitSayisi;
    }

    public void printAllCredit(ArrayList<Kredi> krediArrayList)
    {

        for (Kredi i : krediArrayList)
        {
            Log.d("KREDİ LİST " , "***************");
            Log.d("KREDİ LİST " , "owner no " +i.getOwnerNo());
            Log.d("KREDİ LİST " , "id " +i.getId());
            Log.d("KREDİ LİST " , "miktar "+i.getMiktar());
            Log.d("KREDİ LİST " , "kalan miktar "+i.getKalanMiktar());
            Log.d("KREDİ LİST " , "aylik taksit " + i.getAylikTaksit());
            Log.d("KREDİ LİST " , "taksit sayisi " + i.getTaksitSayisi());
            Log.d("KREDİ LİST " , "***************");
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMiktar() {
        return miktar;
    }

    public void setMiktar(int miktar) {
        this.miktar = miktar;
    }

    public int getTaksitSayisi() {
        return taksitSayisi;
    }

    public void setTaksitSayisi(int taksitSayisi) {
        this.taksitSayisi = taksitSayisi;
    }

    public String getOwnerNo() {
        return ownerNo;
    }

    public void setOwnerNo(String ownerNo) {
        this.ownerNo = ownerNo;
    }

    public double getAylikTaksit() {
        return aylikTaksit;
    }

    public void setAylikTaksit(double aylikTaksit) {
        this.aylikTaksit = aylikTaksit;
    }

    public double getKalanMiktar() {
        return kalanMiktar;
    }

    public void setKalanMiktar(double kalanMiktar) {
        this.kalanMiktar = kalanMiktar;
    }
}
