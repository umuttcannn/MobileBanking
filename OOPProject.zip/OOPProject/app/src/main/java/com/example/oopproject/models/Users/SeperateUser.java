package com.example.oopproject.models.Users;

import android.content.Context;

import com.example.oopproject.MyDatabaseHelper;
import com.example.oopproject.models.Credits.Kredi;
import com.example.oopproject.models.ParametricVariables;

import java.util.ArrayList;

public class SeperateUser extends User{
    public SeperateUser(int bakiye, String ad, String soyad, String tc, String pw, String hesapNo) {
        super(bakiye, ad, soyad, tc, pw, hesapNo);
    }
    public SeperateUser(int bakiye, String ad, String soyad, String tc, String pw, String hesapNo, Context context) {
        super(bakiye, ad, soyad, tc, pw, hesapNo);
        this.context = context;
        myDB = new MyDatabaseHelper(context);
    }

    public SeperateUser(int id, int bakiye, String ad, String soyad, String tc, String pw, String hesapNo, Context context) {
        super(id, bakiye, ad, soyad, tc, pw, hesapNo, context);
    }

    public SeperateUser(Context context){
        super(context);
        this.context = context;
        myDB = new MyDatabaseHelper(context);
    }

    public double krediFaizHesaplama(int cekilenMiktar, int taksitSayisi)
    {
        return (cekilenMiktar/taksitSayisi)+((cekilenMiktar/taksitSayisi)*(ParametricVariables.SEPERATE_KREDIFAIZORANI /10));
    }

    @Override
    public void bakiyeGuncelle(int miktar) {
        super.bakiyeGuncelle(miktar);
    }

    @Override
    public int krediCek(Kredi kredi) {
        super.krediCek(kredi);
        return kredi.getMiktar();
    }

    public ArrayList<User> getSeperateUserList()
    {
        return myDB.getUserList();
    }

}
