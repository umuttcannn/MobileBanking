package com.example.oopproject.models.Users;

import android.content.Context;

import com.example.oopproject.models.Credits.Kredi;
import com.example.oopproject.models.ParametricVariables;

public class FarmerUser extends SeperateUser{

    public FarmerUser(int bakiye, String ad, String soyad, String tc, String pw, String hesapNo) {
        super(bakiye, ad, soyad, tc, pw, hesapNo);
    }

    public FarmerUser(int bakiye, String ad, String soyad, String tc, String pw, String hesapNo, Context context) {
        super(bakiye, ad, soyad, tc, pw, hesapNo, context);
    }

    public FarmerUser(int id, int bakiye, String ad, String soyad, String tc, String pw, String hesapNo, Context context) {
        super(id, bakiye, ad, soyad, tc, pw, hesapNo, context);
    }

    public FarmerUser(Context context) {
        super(context);
    }

    @Override
    public double krediFaizHesaplama(int cekilenMiktar, int taksitSayisi) {
        return (cekilenMiktar/taksitSayisi)+((cekilenMiktar/taksitSayisi)*(ParametricVariables.INTERNAL_KREDIFAIZORANI /10));
    }

    @Override
    public void bakiyeGuncelle(int miktar) {
        super.bakiyeGuncelle(miktar);
    }

    @Override
    public int krediCek(Kredi kredi) {
        return super.krediCek(kredi);
    }
}
