package com.example.oopproject.models;

public abstract class ParametricVariables {

    public static final double SME_KREDIFAIZORANI = 2.08;
    public static final double FARMER_KREDIFAIZORANI = 1.78;
    public static final double INTERNAL_KREDIFAIZORANI = 1.50;
    public static final double RETIRED_KREDIFAIZORANI = 1.80;
    public static final double BUSINESS_KREDIFAIZORANI = 2.20;
    public static final double SEPERATE_KREDIFAIZORANI = 1.88;


}
