package com.example.oopproject.bakiyeUI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.oopproject.MyDatabaseHelper;
import com.example.oopproject.R;
import com.example.oopproject.UserBottomNavigationActivity;
import com.example.oopproject.models.Users.User;

public class DepositActivity extends AppCompatActivity {

    EditText etBakiyeYukle;
    Button btnBakiyeYukle;

    MyDatabaseHelper myDB = new MyDatabaseHelper(DepositActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bakiye_yukle);

        etBakiyeYukle = findViewById(R.id.etBakiyeYukle);
        btnBakiyeYukle = findViewById(R.id.btnBakiyeYukle);

        Intent intent = getIntent();
        String tc = intent.getStringExtra("tc");
        String pw = intent.getStringExtra("pw");

        User user = new User(myDB.getId(tc),myDB.getBakiye(tc),myDB.getUserName(tc),myDB.getUserSurname(tc),tc,pw,myDB.getUserHesapNo(tc),this);

        btnBakiyeYukle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etBakiyeYukle.getText().toString().equals(""))
                {
                    Toast.makeText(DepositActivity.this,"LUTFEN ALANLARI DOLDURUNUZ",Toast.LENGTH_SHORT).show();
                }
                else{
                    // user uzerinden bakiye guncelleme
                    user.bakiyeGuncelle(Integer.parseInt(etBakiyeYukle.getText().toString()));

                    /*
                    if (myDB.getType(tc).equals("BUSINESS"))
                    {
                        myDB.bakiyeGüncelle(myDB.getBakiyefromNo(tc)+Integer.parseInt(etBakiyeYukle.getText().toString()),myDB.getTcFromNo(tc),myDB.getUserNamefromHesapNo(tc),myDB.getUserSurnamefromHesapNo(tc),tc,pw,myDB.getId(tc));

                    }
                    else
                    {

                        myDB.bakiyeGüncelle(myDB.getBakiye(tc)+ Integer.parseInt(etBakiyeYukle.getText().toString()),
                                tc,
                                myDB.getUserName(tc),
                                myDB.getUserSurname(tc),
                                myDB.getUserNamefromHesapNo(tc),
                                pw,
                                myDB.getId(tc));

                    }*/

                    Toast.makeText(DepositActivity.this,"Yeni bakiyeniz : "  + myDB.getBakiye(tc) , Toast.LENGTH_SHORT).show();
                    Intent intent1 = new Intent(DepositActivity.this, UserBottomNavigationActivity.class);

                    intent1.putExtra("tc",tc);
                    intent1.putExtra("pw",pw);
                    startActivity(intent1);


                }


            }
        });

    }
}