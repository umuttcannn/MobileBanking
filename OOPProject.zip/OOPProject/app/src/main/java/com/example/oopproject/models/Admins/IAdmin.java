package com.example.oopproject.models.Admins;

import com.example.oopproject.models.Users.User;

public interface IAdmin {

    void kullaniciGuncelle(int bakiye,String tc,String ad,String soyad,String hesapNo,String pw,int id,String type);

    void kullaniciSil(User user);


}
