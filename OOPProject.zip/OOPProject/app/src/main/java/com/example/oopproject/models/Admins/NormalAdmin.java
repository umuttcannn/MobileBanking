package com.example.oopproject.models.Admins;

import com.example.oopproject.models.Users.User;

public class NormalAdmin extends Admin implements IAdmin{
    public NormalAdmin(String ad, String pw) {
        super(ad, pw);
    }

    @Override
    public void kullaniciGuncelle(int bakiye, String tc, String ad, String soyad, String hesapNo, String pw, int id, String type) {
        super.kullaniciGuncelle(bakiye, tc, ad, soyad, hesapNo, pw, id, type);
    }

    @Override
    public void kullaniciSil(User user) {
        super.kullaniciSil(user);
    }
}
